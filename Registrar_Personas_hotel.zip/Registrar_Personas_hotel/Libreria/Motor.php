<?php
include("Configuracion.php");
include("Conexion.php");
include("Persona.php");

?>